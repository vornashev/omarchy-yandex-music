from typing import TYPE_CHECKING, Any, Optional, Union

from yandex_music import Pin, PinsList
from yandex_music._client_async import log
from yandex_music._client_base import ClientBase

if TYPE_CHECKING:
    from yandex_music.utils.request_async import Request


class PinsMixin(ClientBase):
    """Закреплённые.

    Миксин для методов, связанных с закреплёнными элементами.
    """

    _request: 'Request'

    @log
    async def pins(self, *args: Any, **kwargs: Any) -> Optional[PinsList]:
        """Получение списка закреплённых элементов.

        Args:
            *args: Произвольные аргументы (будут переданы в запрос).
            **kwargs: Произвольные именованные аргументы (будут переданы в запрос).

        Returns:
            :obj:`yandex_music.PinsList` | :obj:`None`: Список закреплённых элементов или :obj:`None`.

        Raises:
            :class:`yandex_music.exceptions.YandexMusicError`: Базовое исключение библиотеки.
        """
        url = f'{self.base_url}/pins'

        result = await self._request.get(url, *args, **kwargs)

        return PinsList.de_json(result, self)

    @log
    async def pin_album(self, album_id: Union[str, int], **kwargs: Any) -> Optional[Pin]:
        """Закрепление альбома.

        Args:
            album_id (:obj:`str` | :obj:`int`): Уникальный идентификатор альбома.
            **kwargs: Произвольные именованные аргументы (будут переданы в запрос).

        Returns:
            :obj:`yandex_music.Pin`: Закреплённый элемент.

        Raises:
            :class:`yandex_music.exceptions.YandexMusicError`: Базовое исключение библиотеки.
        """
        url = f'{self.base_url}/pin/album'

        result = await self._request.put(url, json={'id': album_id}, **kwargs)

        return Pin.de_json(result, self)

    @log
    async def unpin_album(self, album_id: Union[str, int], **kwargs: Any) -> bool:
        """Открепление альбома.

        Args:
            album_id (:obj:`str` | :obj:`int`): Уникальный идентификатор альбома.
            **kwargs: Произвольные именованные аргументы (будут переданы в запрос).

        Returns:
            :obj:`bool`: :obj:`True` при успешном выполнении запроса, иначе :obj:`False`.

        Raises:
            :class:`yandex_music.exceptions.YandexMusicError`: Базовое исключение библиотеки.
        """
        url = f'{self.base_url}/pin/album'

        result = await self._request.delete(url, json={'id': album_id}, **kwargs)

        return result == 'ok'

    @log
    async def pin_artist(self, artist_id: Union[str, int], **kwargs: Any) -> Optional[Pin]:
        """Закрепление артиста.

        Args:
            artist_id (:obj:`str` | :obj:`int`): Уникальный идентификатор артиста.
            **kwargs: Произвольные именованные аргументы (будут переданы в запрос).

        Returns:
            :obj:`yandex_music.Pin`: Закреплённый элемент.

        Raises:
            :class:`yandex_music.exceptions.YandexMusicError`: Базовое исключение библиотеки.
        """
        url = f'{self.base_url}/pin/artist'

        result = await self._request.put(url, json={'id': artist_id}, **kwargs)

        return Pin.de_json(result, self)

    @log
    async def unpin_artist(self, artist_id: Union[str, int], **kwargs: Any) -> bool:
        """Открепление артиста.

        Args:
            artist_id (:obj:`str` | :obj:`int`): Уникальный идентификатор артиста.
            **kwargs: Произвольные именованные аргументы (будут переданы в запрос).

        Returns:
            :obj:`bool`: :obj:`True` при успешном выполнении запроса, иначе :obj:`False`.

        Raises:
            :class:`yandex_music.exceptions.YandexMusicError`: Базовое исключение библиотеки.
        """
        url = f'{self.base_url}/pin/artist'

        result = await self._request.delete(url, json={'id': artist_id}, **kwargs)

        return result == 'ok'

    @log
    async def pin_playlist(self, uid: Union[str, int], kind: Union[str, int], **kwargs: Any) -> Optional[Pin]:
        """Закрепление плейлиста.

        Args:
            uid (:obj:`str` | :obj:`int`): Уникальный идентификатор владельца плейлиста.
            kind (:obj:`str` | :obj:`int`): Номер плейлиста.
            **kwargs: Произвольные именованные аргументы (будут переданы в запрос).

        Returns:
            :obj:`yandex_music.Pin`: Закреплённый элемент.

        Raises:
            :class:`yandex_music.exceptions.YandexMusicError`: Базовое исключение библиотеки.
        """
        url = f'{self.base_url}/pin/playlist'

        result = await self._request.put(url, json={'uid': uid, 'kind': kind}, **kwargs)

        return Pin.de_json(result, self)

    @log
    async def unpin_playlist(self, uid: Union[str, int], kind: Union[str, int], **kwargs: Any) -> bool:
        """Открепление плейлиста.

        Args:
            uid (:obj:`str` | :obj:`int`): Уникальный идентификатор владельца плейлиста.
            kind (:obj:`str` | :obj:`int`): Номер плейлиста.
            **kwargs: Произвольные именованные аргументы (будут переданы в запрос).

        Returns:
            :obj:`bool`: :obj:`True` при успешном выполнении запроса, иначе :obj:`False`.

        Raises:
            :class:`yandex_music.exceptions.YandexMusicError`: Базовое исключение библиотеки.
        """
        url = f'{self.base_url}/pin/playlist'

        result = await self._request.delete(url, json={'uid': uid, 'kind': kind}, **kwargs)

        return result == 'ok'

    @log
    async def pin_wave(self, seeds: str, **kwargs: Any) -> Optional[Pin]:
        """Закрепление волны.

        Args:
            seeds (:obj:`str`): Идентификатор волны (например, "artist:12345").
            **kwargs: Произвольные именованные аргументы (будут переданы в запрос).

        Returns:
            :obj:`yandex_music.Pin`: Закреплённый элемент.

        Raises:
            :class:`yandex_music.exceptions.YandexMusicError`: Базовое исключение библиотеки.
        """
        url = f'{self.base_url}/pin/wave'

        result = await self._request.put(url, json={'seeds': seeds}, **kwargs)

        return Pin.de_json(result, self)

    @log
    async def unpin_wave(self, seeds: str, **kwargs: Any) -> bool:
        """Открепление волны.

        Args:
            seeds (:obj:`str`): Идентификатор волны.
            **kwargs: Произвольные именованные аргументы (будут переданы в запрос).

        Returns:
            :obj:`bool`: :obj:`True` при успешном выполнении запроса, иначе :obj:`False`.

        Raises:
            :class:`yandex_music.exceptions.YandexMusicError`: Базовое исключение библиотеки.
        """
        url = f'{self.base_url}/pin/wave'

        result = await self._request.delete(url, json={'seeds': seeds}, **kwargs)

        return result == 'ok'
