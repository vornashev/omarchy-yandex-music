from dataclasses import field
from typing import TYPE_CHECKING, List, Optional

from yandex_music import YandexMusicModel
from yandex_music.utils import model

if TYPE_CHECKING:
    from yandex_music import AutoRenewable, ClientType, NonAutoRenewable, Operator, RenewableRemainder


@model
class Subscription(YandexMusicModel):
    """Класс, представляющий информацию о подписках пользователя.

    Attributes:
        auto_renewable (:obj:`list` из :obj:`yandex_music.AutoRenewable`, optional): Автопродление.
        family_auto_renewable (:obj:`list` из :obj:`yandex_music.AutoRenewable`): Автопродление семейной подписки.
        non_auto_renewable_remainder (:obj:`yandex_music.RenewableRemainder`, optional): Напоминание о продлении. Может
            не приходить в статусе аккаунта (:func:`yandex_music.Client.account_status`).
        operator (:obj:`list` из :obj:`yandex_music.Operator`, optional): Услуги сотового оператора.
        non_auto_renewable (:obj:`yandex_music.NonAutoRenewable`, optional): Отключённое автопродление.
        can_start_trial (:obj:`bool`, optional): Есть ли возможность начать пробный период.
        mcdonalds (:obj:`bool`, optional): mcdonalds TODO.
        end (:obj:`str`, optional): Дата окончания.
        had_any_subscription (:obj:`bool`, optional): Наличие какой-либо подписки в прошлом. Не приходит
            в статусе аккаунта радио (:func:`yandex_music.Client.rotor_account_status`).
        client (:obj:`yandex_music.Client`, optional): Клиент Yandex Music.
    """

    auto_renewable: List['AutoRenewable']
    family_auto_renewable: List['AutoRenewable']
    non_auto_renewable_remainder: Optional['RenewableRemainder'] = None
    had_any_subscription: Optional[bool] = None
    operator: List['Operator'] = field(default_factory=list)
    non_auto_renewable: Optional['NonAutoRenewable'] = None
    can_start_trial: Optional[bool] = None
    mcdonalds: Optional[bool] = None
    end: Optional[str] = None
    client: Optional['ClientType'] = None

    def __post_init__(self) -> None:
        self._id_attrs = (self.non_auto_renewable_remainder, self.auto_renewable, self.family_auto_renewable)
