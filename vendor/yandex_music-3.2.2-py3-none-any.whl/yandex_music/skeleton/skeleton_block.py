from typing import TYPE_CHECKING, Optional

from yandex_music import YandexMusicModel
from yandex_music.utils import model

if TYPE_CHECKING:
    from yandex_music import ClientType
    from yandex_music.skeleton.skeleton_block_data import SkeletonBlockData


@model
class SkeletonBlock(YandexMusicModel):
    """Класс, представляющий блок скелетона.

    Note:
        Известные значения поля ``type`` для страницы артиста: ``TABS``, ``ARTIST_RELEASE``,
        ``ARTIST_POPULAR_TRACKS``, ``FAMILIAR_YOU``, ``ARTIST_ALBUMS``, ``ARTIST_PLAYLISTS``,
        ``BANDLINK_SCANNER``, ``ARTIST_COMPILATIONS``, ``SIMILAR_ARTISTS``.

        Известные значения поля ``type`` для страницы концерта: ``TABS``, ``CONCERT_PLACE``,
        ``ARTIST_CONCERTS``.

    Attributes:
        id (:obj:`str`, optional): Идентификатор блока.
        type (:obj:`str`, optional): Тип блока.
        data (:obj:`yandex_music.SkeletonBlockData`, optional): Данные блока.
        client (:obj:`yandex_music.Client`, optional): Клиент Yandex Music.
    """

    id: Optional[str] = None
    type: Optional[str] = None
    data: Optional['SkeletonBlockData'] = None
    client: Optional['ClientType'] = None

    def __post_init__(self) -> None:
        self._id_attrs = (self.id, self.type)
