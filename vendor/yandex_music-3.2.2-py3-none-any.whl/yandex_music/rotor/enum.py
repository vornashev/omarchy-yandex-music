from typing import TYPE_CHECKING, List, Optional

from yandex_music import YandexMusicModel
from yandex_music.utils import model

if TYPE_CHECKING:
    from yandex_music import ClientType, Value


@model
class Enum(YandexMusicModel):
    """Класс, представляющий перечисления.

    Attributes:
        type (:obj:`str`): Тип перечисления.
        name (:obj:`str`): Название перечисления.
        possible_values (:obj:`list` из :obj:`yandex_music.Value`): Доступные значения.
        client (:obj:`yandex_music.Client`, optional): Клиент Yandex Music.
        **kwargs: Произвольные ключевые аргументы полученные от API.
    """

    type: str
    name: str
    possible_values: List['Value']
    client: Optional['ClientType'] = None

    def __post_init__(self) -> None:
        self._id_attrs = (self.type, self.name, self.possible_values)
